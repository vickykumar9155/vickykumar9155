function Show() {
    document.getElementById("test").style.display = 'block';
}

function Hide() {
    document.getElementById("test").style.display = 'none';
}

function showHide() {
    document.getElementById("table").style.display = 'none';
}


location.href = "/Home.html";